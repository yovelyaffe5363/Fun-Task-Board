<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Task;

class TaskController extends Controller
{
    public function all() // Get all tasks details
    {
        $tasks = Task::all();
        
        return response()->json([
            'status' => 200,
            'tasks' => $tasks,
            'message' => 'All data are here.',
        ]);
    }
    
    public function info($id) // Get one task details (by request id)
    {
        
        $task = Task::find($id);
        
        return response()->json([
            'status' => 200,
            'task' => $task,
            'message' => 'All Task data is here.',
        ]);
    }
    
    public function update(Request $request , $id) // Update task details (by request id)
    {
        $task = Task::find($id);
        $task->name = $request->input('name');
        $task->date = $request->input('date');
        $task->description = $request->input('description');
        $task->status = $request->input('status');
        $task->update();
        
        return response()->json([
            'status' => 200,
            'message' => 'Task (#'.$id.') Updated Successfully :)',
        ]);
    }
    
    public function delete($id) // Delete task (by request id)
    {
        $task = Task::find($id);
        $task->delete();
        
        return response()->json([
            'status' => 200,
            'message' => 'Task (#'.$id.') deleted Successfully :)',
        ]);
    }

    public function save(Request $request) // Save new task 
    {
        $validation = Validator::make($request->all(),[
            'name' => 'required|max:191',
            'date' => 'date',
            'description' => 'nullable|max:191',
            'status' => 'nullable',
        ]);
        
        if ($validation->fails()){
            return response()->json([
                'status' => 401,
                'message' => $validation->messages(),
            ]);
        }
        else{
            $task = new Task;
            $task->name = $request->input('name');
            $task->date = $request->input('date');
            $task->description = $request->input('description') ?? '';
            $task->status = $request->input('status') ?? '0';
            $task->save();
            
            return response()->json([
                'status' => 200,
                'message' => 'Task Added Successfully :)',
            ]);
        }
    }
}
