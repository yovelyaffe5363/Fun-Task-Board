import './App.css';

import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';

import Tasks from './components/Tasks';
import AddTask from './components/AddTask';
import EditTask from './components/EditTask';

function App() {
  return (
    <div className="App py-5">
      <Router>
        <Switch>

          <Route exact path="/" component={Tasks} />
          <Route path="/home" component={Tasks} />

          <Route path="/add-task" component={AddTask} />
          <Route path="/edit-task/:id" component={EditTask} />

        </Switch>
      </Router>
    </div>
  );
}

export default App;
