import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import swal from 'sweetalert';
// import { useTable, useSortBy } from 'react-table';

const url = 'http://localhost:8000/api';

class Tasks extends Component {

    state = {
        tasks: [],
        summary: {
            totalTasks: 0,
            completedTasks: 0,
            remainingTasks: 0
        },
        loading: true,
        filters: {
            fromDate: '',
            untilDate: '',
            status: 'ALL',
        }
    };

    async componentDidMount() {
        this.getAllTasks();
    }

    getAllTasks = () => {
        axios.get(url + `/tasks`).then(
            res => {
                if (res.data.status === 200) {
                    if (this.state.filters.status !== 'ALL') {
                        res.data.tasks = res.data.tasks.filter(t =>
                            t.status === this.state.filters.status
                        )
                    }
                    if (this.state.filters.fromDate !== '') {
                        res.data.tasks = res.data.tasks.filter(t =>
                            new Date(t.date) >= new Date(this.state.filters.fromDate)
                        )
                    }
                    if (this.state.filters.untilDate !== '') {
                        res.data.tasks = res.data.tasks.filter(t =>
                            new Date(t.date) <= new Date(this.state.filters.untilDate)
                        )
                    }

                    this.setState({
                        tasks: res.data.tasks,
                        summary: {
                            totalTasks: res.data.tasks.length,
                            completedTasks: res.data.tasks.filter(t => t.status === '1').length,
                            remainingTasks: res.data.tasks.filter(t => t.status === '0').length
                        },
                        loading: false,
                        filters: {
                            fromDate: this.state.filters.fromDate,
                            untilDate: this.state.filters.untilDate,
                            status: this.state.filters.status,
                        }
                    });
                }
                else {
                    console.log(res.data);
                    swal({
                        title: 'התרחשה שגיאה במערכת, אנא פנה לתמיכה או נסה שנית מאוחר יותר',
                        text: res.data.message,
                        icon: 'error',
                        buttons: 'סגור',
                    });
                }
            });
    }

    toggleTaskStatus = (e, taskId, status) => {
        var item = this.state.tasks.find(t => t.id == taskId);

        item.status = status;
        axios.put(url + `/update-task/${taskId}`, item).then(
            res => {
                if (res.data.status === 200) {
                    if (status) {
                        swal({
                            title: '!מעולה',
                            text: 'משימה משמעותית סגרנו',
                            icon: 'success',
                            buttons: 'סגור',
                        });
                    }
                    else {
                        swal({
                            title: '!חוזרים לעניינים',
                            text: ';) חשוב לסגור את כל הקצוות',
                            icon: 'info',
                            buttons: 'סגור',
                        });
                    }
                    this.getAllTasks();
                }
                else {
                    console.log(res.data);
                    swal({
                        title: 'התרחשה שגיאה במערכת, אנא פנה לתמיכה או נסה שנית מאוחר יותר',
                        text: res.data.message,
                        icon: 'error',
                        buttons: 'סגור',
                    });
                }
            });
    }

    inputChangedEvent = (e) => {
        switch (e.target.name) {
            case 'fromDate':
                this.setState({
                    tasks: this.state.tasks,
                    summary: {
                        totalTasks: this.state.tasks.length,
                        completedTasks: this.state.tasks.filter(t => t.status === '1').length,
                        remainingTasks: this.state.tasks.filter(t => t.status === '0').length
                    },
                    loading: false,
                    filters: {
                        fromDate: new Date(e.target.value).toISOString().split("T")[0],
                        untilDate: this.state.filters.untilDate,
                        status: this.state.filters.status,
                    }
                });
                break;
            case 'untilDate':
                this.setState({
                    tasks: this.state.tasks,
                    summary: {
                        totalTasks: this.state.tasks.length,
                        completedTasks: this.state.tasks.filter(t => t.status === '1').length,
                        remainingTasks: this.state.tasks.filter(t => t.status === '0').length
                    },
                    loading: false,
                    filters: {
                        fromDate: this.state.filters.fromDate,
                        untilDate: new Date(e.target.value).toISOString().split("T")[0],
                        status: this.state.filters.status,
                    }
                });
                break;
            case 'status':
                this.setState({
                    tasks: this.state.tasks,
                    summary: {
                        totalTasks: this.state.tasks.length,
                        completedTasks: this.state.tasks.filter(t => t.status === '1').length,
                        remainingTasks: this.state.tasks.filter(t => t.status === '0').length
                    },
                    loading: false,
                    filters: {
                        fromDate: this.state.filters.fromDate,
                        untilDate: this.state.filters.untilDate,
                        status: e.target.value,
                    }
                });
                break;

            default: break;
        }
    }

    cleanFiltersFields = (e) => {
        this.setState({
            tasks: this.state.tasks,
            summary: {
                totalTasks: this.state.tasks.length,
                completedTasks: this.state.tasks.filter(t => t.status === '1').length,
                remainingTasks: this.state.tasks.filter(t => t.status === '0').length
            },
            loading: false,
            filters: {
                fromDate: '',
                untilDate: '',
                status: 'ALL',
            }
        });
    }

    deleteTask = (e, taskId) => {
        var item = this.state.tasks.find(t => t.id == taskId);

        if (((new Date(item.date) - new Date()) / 86400000) <= 6) {
            swal({
                title: 'שגיאה במחיקת המשימה',
                text: '!לא ניתן למחוק משימה כאשר תאריך היעד שלה פחות מ-6 ימים',
                icon: 'error',
                buttons: 'אופס',
            });
            return;
        }
        axios.delete(url + `/delete-task/${taskId}`).then(
            res => {
                if (res.data.status === 200) {
                    swal({
                        title: `מוחקים את המשימה`,
                        text: '...גם ככה היא לא הייתה משהו',
                        icon: 'warning',
                        buttons: 'יאללה לפח',
                    });
                    this.getAllTasks();
                }
                else {
                    console.log(res.data);
                    swal({
                        title: 'התרחשה שגיאה במערכת, אנא פנה לתמיכה או נסה שנית מאוחר יותר',
                        text: res.data.message,
                        icon: 'error',
                        buttons: 'סגור',
                    });
                }
            });
    }

    formatDate = (date) => {
        let array = date.split("-");
        let formatedDate = '' + array[2] + '/' + array[1] + '/' + array[0];
        return formatedDate;
    }

    render() {
        var tasks_table = '';
        if (this.state.loading) {
            tasks_table = <tr><td colSpan="7"><h2 className='m-5'>טעינת נתונים...</h2></td></tr>
        }
        else {
            if (this.state.tasks.length === 0) {
                tasks_table = <tr><td colSpan="7"><h2 className='m-5'>לא נמצאו משימות...</h2></td></tr>
            }
            else {
                tasks_table = this.state.tasks.map((item) => {
                    return (
                        <tr key={item.id}>
                            <td>{item.id}</td>
                            <td>{item.name}</td>
                            <td>{this.formatDate(item.date)}</td>
                            <td>{item.description}</td>
                            <td>
                                {item.status === '1' ?
                                    <button type="button" onClick={(e) => this.toggleTaskStatus(e, `${item.id}`, 0)} className="btn btn-success m-1 brn-sm">
                                        <i className="fa fa-check-circle" aria-hidden="true"></i>
                                    </button> :
                                    <button type="button" onClick={(e) => this.toggleTaskStatus(e, `${item.id}`, 1)} className="btn btn-warning m-1 brn-sm">
                                        <i className="fa fa-exclamation-circle" aria-hidden="true"></i>
                                    </button>
                                }</td>
                            <td>
                                <Link to={`edit-task/${item.id}`} className="btn btn-info m-1 brn-sm">עריכה</Link>
                                <button type="button" onClick={(e) => this.deleteTask(e, `${item.id}`)} className="btn btn-danger m-1 brn-sm">מחיקה</button>
                            </td>
                        </tr >
                    )
                })
            }
        }
        return (
            <div>
                <div className="container mb-4 col-md-8">
                    <div className="card">
                        <div className="card-header">
                            <ul className="nav nav-pills justify-content-center">
                                <li className="nav-item summary">
                                    <span className="btn btn-outline-dark p-2 m-3 me-2">
                                        כל המשימות&nbsp;
                                        <span className="badge badge-pill blueDot">{this.state.summary.totalTasks}</span>
                                    </span>
                                </li>
                                <li className="nav-item summary">
                                    <span className="btn btn-outline-dark p-2 m-3 me-2">
                                        משימות שהושלמו&nbsp;
                                        <span className="badge badge-pill greenDot">{this.state.summary.completedTasks}</span>
                                    </span>
                                </li>
                                <li className="nav-item summary">
                                    <span className="btn btn-outline-dark p-2 m-3 me-2">
                                        משימות שנותרו&nbsp;
                                        <span className="badge badge-pill yellowDot">{this.state.summary.remainingTasks}</span>
                                    </span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div className="container">
                    <div className="row justify-content-center">
                        <div className="col-md-10">
                            <div className="card">
                                <div className="card-header">
                                    <h4>לוח המשימות שלי
                                        <Link to={'/add-task'} className="btn btn-success btn-sm float-end">
                                            הוספת משימה&nbsp;
                                            <i className="fa fa-plus-circle" aria-hidden="true"></i>
                                        </Link>
                                    </h4>
                                </div>
                                <div className="card-body">
                                    <div>
                                        <div className="form-group tableFilters mb-3">
                                            <div>
                                                <b>מתאריך</b>
                                                <input type="date" name="fromDate" value={this.state.filters.fromDate} onChange={this.inputChangedEvent} className="form-control m-3" />
                                            </div>
                                            <div>
                                                <b>עד תאריך</b>
                                                <input type="date" name="untilDate" value={this.state.filters.untilDate} onChange={this.inputChangedEvent} className="form-control m-3" />
                                            </div>
                                            <div>
                                                <b>סטטוס</b>
                                                <select className="form-control m-3" value={this.state.filters.status} name="status" onChange={this.inputChangedEvent}>
                                                    <option value={"ALL"}>הכל</option>
                                                    <option value={"1"}>משימות שהושלמו</option>
                                                    <option value={"0"}>משימות שנותרו</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div className="form-group tableFilters mb-3 justify-content-center">
                                            <button type="button" onClick={(e) => this.getAllTasks()} className="btn btn-success m-1 brn-sm">
                                                חיפוש לפי&nbsp;
                                                <i className="fa fa-search" aria-hidden="true"></i>
                                            </button>
                                            <button type="button" onClick={(e) => this.cleanFiltersFields()} className="btn btn-info m-1 brn-sm">
                                                נקה שדות&nbsp;
                                                <i className="fa fa-eraser" aria-hidden="true"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <hr />
                                    <table className="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>כותרת</th>
                                                <th>תאריך יעד</th>
                                                <th>תיאור</th>
                                                <th>סטטוס</th>
                                                <th>פעולות</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {tasks_table}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div >
        );
    }
}

export default Tasks;