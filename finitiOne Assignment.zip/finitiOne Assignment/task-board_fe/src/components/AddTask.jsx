import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import swal from 'sweetalert';

class AddTask extends Component {

    url = 'http://localhost:8000/api';
    todayDate = new Date();

    state = {
        name: '',
        date: '',
        description: '',
        status: '',
    };

    inputChangedEvent = (e) => {
        e.persist();
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    saveTask = async (e) => {
        e.preventDefault();
        if (!(this.state.description)) this.state.description = '-';
        if ((new Date(this.state.date) - new Date()) < -86400000) { // 86400000 miliseconds in one day
            swal({
                title: 'שגיאה בהוספת המשימה',
                text: '!תאריך היעד אינו יכול להיות בעבר',
                icon: 'error',
                buttons: 'אופס, אנסה שנית',
            });
            return;
        }
        axios.post(this.url + `/add-task`, this.state).then(
            res => {
                if (res.data.status === 200) {
                    this.setState({
                        name: '',
                        date: '',
                        description: '',
                        status: '',
                    });
                    swal({
                        title: 'כל הכבוד, אנחנו גאים בך',
                        text: '!הוספת עוד משימה משמעותית ללוח שלך',
                        icon: 'success',
                        buttons: '(: תודה',
                    });
                }
                else if (res.data.status === 401) {
                    var errorMessage = '';
                    if (res.data.message.hasOwnProperty('name')) errorMessage = '!לא הוזן שם משימה תקין';
                    else if (res.data.message.hasOwnProperty('date')) errorMessage = '!לא הוזן תאריך יעד תקין';
                    swal({
                        title: 'שגיאה בהוספת המשימה',
                        text: errorMessage,
                        icon: 'error',
                        buttons: 'אופס, אנסה שנית',
                    });
                }
                else {
                    console.log(res.data);
                    swal({
                        title: 'התרחשה שגיאה במערכת, אנא פנה לתמיכה או נסה שנית מאוחר יותר',
                        text: res.data.message,
                        icon: 'error',
                        buttons: 'סגור',
                    });
                }
            }
        );
    }

    render() {
        return (
            <div>
                <div className="container">
                    <div className="row justify-content-center">
                        <div className="col-md-6">
                            <div className="card">
                                <div className="card-header">
                                    <h4>הוספת משימה חדשה
                                        <Link to={'/'} className="btn btn-success btn-sm float-end">חזור</Link>
                                    </h4>
                                </div>
                                <div className="card-body">
                                    <form onSubmit={this.saveTask} >
                                        <div className="form-group mb-3">
                                            <label>שם המשימה</label>
                                            <input placeholder='כותרת שתכוון אותנו' type="text" name="name" value={this.state.name} onChange={this.inputChangedEvent} className="form-control" />
                                        </div>
                                        <div className="form-group mb-3">
                                            <label>תאריך יעד</label>
                                            <input type="date" name="date" value={this.state.date} onChange={this.inputChangedEvent} className="form-control" />
                                        </div>
                                        <div className="form-group mb-3">
                                            <label>תיאור המשימה</label>
                                            <input placeholder='הערות/פרטים נוספים' type="text" name="description" value={this.state.description}
                                                onChange={this.inputChangedEvent} className="form-control" />
                                        </div>
                                        <div className="form-group mb-3">
                                            <button type="submit" className="btn btn-primary">שמור משימה</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default AddTask;