import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import swal from 'sweetalert';

class EditTask extends Component {

    url = 'http://localhost:8000/api';
    task_id = this.props.match.params.id;

    state = {
        name: '',
        date: '',
        description: '',
        status: ''
    };

    componentDidMount() {
        axios.get(this.url + `/info-task/${this.task_id}`).then(
            res => {
                if (res.data.status === 200) {
                    let task = res.data.task;
                    this.setState({
                        name: task.name,
                        date: task.date,
                        description: task.description,
                        status: task.status
                    })
                }
                else {
                    console.log(res.data);
                    swal({
                        title: 'התרחשה שגיאה במערכת, אנא פנה לתמיכה או נסה שנית מאוחר יותר',
                        text: res.data.message,
                        icon: 'error',
                        buttons: 'סגור',
                    });
                }
            });
    }

    input = (e) => {
        e.persist();
        this.setState({
            [e.target.name]: e.target.value,
        })
    }

    updateTask = async (e) => {
        e.preventDefault();
        if (!(this.state.description)) this.state.description = '-';
        console.log(this.state);
        axios.put(this.url + `/update-task/${this.task_id}`, this.state).then(
            res => {
                if (res.data.status === 200) {
                    swal({
                        title: '!מעולה',
                        text: 'פרטי המשימה מעודכנים, עכשיו נותר רק להשלים אותה',
                        icon: 'success',
                        buttons: 'סגור',
                    });
                }
                else {
                    console.log(res.data);
                    swal({
                        title: 'התרחשה שגיאה במערכת, אנא פנה לתמיכה או נסה שנית מאוחר יותר',
                        text: res.data.message,
                        icon: 'error',
                        buttons: 'סגור',
                    });
                }
            });
    }

    render() {
        return (
            <div>
                <div className="container">
                    <div className="row justify-content-center">
                        <div className="col-md-6">
                            <div className="card">
                                <div className="card-header">
                                    <h4>עדכון פרטי המשימה
                                        <Link to={'/'} className="btn btn-success btn-sm float-end">חזור</Link>
                                    </h4>
                                </div>
                                <div className="card-body">
                                    <form onSubmit={this.updateTask} >
                                        <div className="form-group mb-3">
                                            <label>שם המשימה</label>
                                            <input placeholder='כותרת שתכוון אותנו' type="text" name="name" value={this.state.name} onChange={this.input} className="form-control" />
                                        </div>
                                        <div className="form-group mb-3">
                                            <label>תאריך יעד</label>
                                            <input type="date" name="date" value={this.state.date} onChange={this.input} className="form-control" />
                                        </div>
                                        <div className="form-group mb-3">
                                            <label>תיאור המשימה</label>
                                            <input placeholder='הערות/פרטים נוספים' type="text" name="description" value={this.state.description} onChange={this.input} className="form-control" />
                                        </div>
                                        <div className="form-group mb-3">
                                            <button type="submit" className="btn btn-primary">שמירה</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default EditTask;