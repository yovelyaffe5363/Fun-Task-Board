Dear FinityOne!
------------------


The Story =>
------------------
First I would like to mention, due to some personal issues I began to work on this task only this Sunday(18/09), so I had to work at nights and of course, speed up recovering my React memory.

I must admit, I came across many features I didn't know and yet it went well, and somehow I had some fun building this 'Todo' program while practicing some dev tools I didn't use for a long time so actually it was exciting Homework :)

Unfortunately, very close to the finish line while working on your last requirements, I noticed that for enabling the sorting of my main table it is almost mandatory to use one of the open-source libraries such as 'react-table', I started to learn how to use that library with online videos.
So meanwhile the process to rewrite my code in order to finish implementing that tool I may exceed my deadline time so I came to the conclusion although I am a very perfectionist person, I decided in this specific situation to give up on this minor feature...
Besides that, all the other requirements are implemented in th program and running nicely!

I really hope this won't affect my chances to continue with you, I have invested many efforts this week and yet I think I manage to program great results.
------------------



My Tool Box:
------------------
FrontSide - React JSX [18.2.0]
BackSide - Laravel framework [6.0]
DB - MySQL / PhpMyAdmin
Node 14
XAMPP Control Panel [V3.3.0] + Apache 

**Please make sure to install node models before running
------------------



Happy Holiday and Lovely Weekend!!
Yovel Yaffe
0503028359
